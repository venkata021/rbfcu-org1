jQuery(document).ready(function($) {
	registerToggles();
	$(window).on("orientationchange resize", function() {
		registerToggles();
	});
});

function registerToggles() {
	var $trigger = $(".que-holder");
	$trigger.off("click");
	if ($(window).width() < 768) {
		$trigger.on("click", function() {
			$(this).next().stop().slideToggle();
		});
	}
}
