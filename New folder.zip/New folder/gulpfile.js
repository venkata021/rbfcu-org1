var gulp = require('gulp');

var replace = require('gulp-replace');

gulp.task('default', function() {
    gulp.src(['main.html'])
        .pipe(replace('holder', 'foo'))
        .pipe(gulp.dest('build/'));
});
