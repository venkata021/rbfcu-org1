var rates = {};
rates.baseurl = "https://echo.rbfcu.org/rate";
//rates.baseurl = "http://is-pc80.rbfcu.local:9080/rate";
//rates.baseurl = "/rate";
rates.grouploaded = false;
rates.productloaded = false;
rates.description = {};
rates.description.deposit = "See our rates for savings and checking accounts, money market accounts, and IRA accounts.";
rates.description.consumer = "Auto loans, personal loans, credit cards and more - let us provide the financing that will get you on the road to success.";
rates.description.mortgage = "Whether you're buying, building, or refinancing a home, our competitive rates make the process easy.";
rates.description.home_equity = "Leverage the value of your home with a home equity loan or home equity line of credit (HELOC).";

rates.definition = {};
rates.definition.apr = "APR means Annual Percentage Rate. The specific rate and term will be dependent upon your credit rating, collateral value, amount financed, and other factors. Rates and terms are subject to change without prior notice; other restrictions may apply.";

rates.disclosure = {};
rates.disclosure.deposit = "Rates and terms are subject to change without prior notice; other restrictions may apply. Fees could reduce the earnings on the account. APY means Annual Percentage Yield. The dividend rate is the declared annual dividend rate paid on an account, which does not reflect compounding.";
rates.disclosure.construction = "At least 20 percent equity is required to secure a construction loan. Interim construction loan with terms up to 1 year are available. Accrued interest is payable with each draw. One time closes are available.";
rates.disclosure.vehicle = "Rates will be reduced by .20% for application submitted online.";
rates.disclosure.primary_mortgage = "Loans exceeding 90% Loan to Value will require Private Mortgage Insurance or a piggyback loan (90/5/5) and are subject to additional qualifications.";
rates.disclosure.secondary_mortgage = "10% equity required.";
rates.disclosure.land = "Loans exceeding 80% Loan to Value are priced 30 basis points higher and are subject to additional qualifications.";
rates.disclosure.home_equity = "At least 20 percent equity is required to secure a home equity loan. APR means Annual Percentage Rate. Your specific rate will be dependent upon your credit rating, term of the loan, and lien position. 30 year terms for Home Equity Loans are only offered as the first lien on the property. Generally, closing costs will be paid by the credit union; however, in some instances certain costs will be paid by the member. Hazard insurance is required. Minimum loan amount is $5,000.";

(function() {
	// --------------- individual rate boxes
	
	$(document).ready(function () {
		var $items = $(".rate[data-rate-config]");
		$items.each(function (index, elem) {
			var $elem = $(elem);
			var rateConfig = $elem.data("rate-config");
			if (!rateConfig) {
				return true; // continue to next element
			}
			if (rateConfig.productId) {
				// TODO call API with all products at once
				var url = rates.baseurl + "/products/" + encodeURI(rateConfig.productId);
				$.get({
					url: url,
					dataType: "jsonp",
					success: function (response) {
						populateIndividual($elem, rateConfig, response);
					}
				});
			}
		});
	});
	
	function populateIndividual($rateElem, rateConfig, rateResponse) {
		var desiredTier = findTier(rateConfig, rateResponse);
		if (!desiredTier) {
			return;
		}
		if (rateResponse.groupId == "DEP") {
			populatePrimary($rateElem, desiredTier.minAnnualRate, "apy");
		} else if (rateResponse.groupId == "CON") {
			$rateElem.find(".pretext").text("as low as");
			populatePrimary($rateElem, desiredTier.minAnnualRate, "apr");
			if (desiredTier.monthsDuration) {
				// some consumer lending products don't have a duration (credit card)
				populateSecondary($rateElem, desiredTier.monthsDuration + " months", "term");
			} else {
				populateSecondary($rateElem, desiredTier.description, "type");
			}
		} else if (rateResponse.groupId == "MOR") {
			populatePrimary($rateElem, desiredTier.minAnnualRate, "apr");
			populateSecondary($rateElem, desiredTier.minRate, "rate");
		} else if (rateResponse.groupId == "HOM") {
			populatePrimary($rateElem, desiredTier.minAnnualRate, "apr");
			var years = desiredTier.monthsDuration / 12;
			populateSecondary($rateElem, years + " years", "term");
		}
		
	}
	
	function findTier(rateConfig, rateResponse) {
		try {
			if (!rateResponse || !rateResponse.tiers || !rateResponse.tiers.length) {
				return null;
			}
			if (rateConfig.tierCalc) {
				// DOM is configured to look for specific tier
				var calcs = rateConfig.tierCalc.split(";");
				for (var i = 0; i < rateResponse.tiers.length; i++) {
					var tier = rateResponse.tiers[i];
					if (tierMatchesRequirements(tier, calcs)) {
						return tier;
					}
				}
			}
			return rateResponse.tiers[0];
		} catch (err) {
		}
		return null;
	}
	
	function populatePrimary($elem, value, description) {
		populateByIndex($elem, value, description, 0);
	}
	
	function populateSecondary($elem, value, description) {
		populateByIndex($elem, value, description, 1);
	}
	
	function populateByIndex($elem, value, description, index) {
		var $container = $elem.find(".rate__entry").eq(index);
		var $value = $container.find(".value");
		$value.text(value);
		if ($.isNumeric(value)) {
			$value.parent().addClass("percentage");
		}
		$container.find(".description").text(description);
	}
	
	function tierMatchesRequirements(tier, requirements) {
		// requirements = array of name=value, where name is the property name on the tier object and value is what that property's value should be
		// 		if all requirements are met, the tier is a match
		for (var i = 0; i < requirements.length; i++) {
			var parts = requirements[i].split("=");
			var propName = parts[0];
			var propVal = parts[1];
			if (tier[propName] != propVal) { // if propName == xxx, tier[propName] is same as JSON tier.xxx
				return false;
			}
		}
		return true;
	}
	
	
	// --------------- rates homepage
	$(document).ready(function () {
		var $items = $(".rate-detail-holder[data-rate-config]");
		$items.each(function (index, elem) {
			var $elem = $(elem);
			var rateConfig = $elem.data("rate-config");
			if (typeof rateConfig === "string") {
				// HTML output had attribute value with single quotes, not double; jquery .data() requires double quotes
				var json = $elem.attr("data-rate-config").replace(/'/g, '"');
				rateConfig = $.parseJSON(json);
			}
			if (!rateConfig) {
				return true; // continue to next element
			}
			if (rateConfig.groupId) {
				var url = rates.baseurl + "/groups/" + encodeURI(rateConfig.groupId);
				$.get({
					url: url,
					dataType: "jsonp",
					success: function (response) {
						populateHomepage($elem, response);
					}
				});
			}
		});
		
		openDesiredRateGroup();
	});
	
	function populateHomepage($rateElem, rateResponse) {
		if (!rateResponse || !rateResponse.products || !rateResponse.products.length) {
			return;
		}
		var $productShell = $rateElem.find(".rate-products-holder li");
		
		var $productContainer = $("<ul></ul>"); // used so DOM is only updated once at end
		for (var i = 0; i < rateResponse.products.length; i++) {
			$productContainer.append($productShell.clone());
		}
		var $productContainers = $productContainer.children();
		$.each(rateResponse.products, function (index) {
			var $elem = $productContainers.eq(index); // <li> element
			var productResponse = rateResponse.products[index];
			var groupId = productResponse.groupId;
			var productId = productResponse.id;
			
			$elem.attr("id", productId);
			$elem.find(".title").html(productResponse.name);
			
			var $table = $elem.find(".rwd-table");
			if (groupId == "DEP") {
				
				if (productId == "SAV" || productId == "CHE") {
					var headers = [ "Minimum Opening Balance", "Dividend Rate", "APY" ];
					setTableHeaders($table, headers);
					addTableRow($table, headers, [ "$1", productResponse.tiers[0].minRate, productResponse.tiers[0].minAnnualRate ]);
				} else if (productId == "CER" || productId == "BUS") {
					var headers = [ "Months", "Amount", "Dividend Rate", "APY" ];
					setTableHeaders($table, headers);
					var numSubTiers = getNumberOfSubTiers(productResponse.tiers, "monthsDuration");
					var itemsPerSubTier = productResponse.tiers.length / numSubTiers; // it's important to note that this assumes each subtier has the same number of elements
					for (var i = 0; i < productResponse.tiers.length; i++) {
						var tier = productResponse.tiers[i];
						var firstSubTier = (i % itemsPerSubTier) == 0;
						var monthHeader = firstSubTier ? tier.monthsDuration : "";
						var amountRange = "$" + tier.minAmount + " - $" + tier.maxAmount;
						addTableRow($table, headers, [ monthHeader, amountRange, tier.minRate + "%", tier.minAnnualRate + "%" ]);
					}
				} else {
					var headers = [ "Amount", "Dividend Rate", "APY" ];
					setTableHeaders($table, headers);
					for (var i = 0; i < productResponse.tiers.length; i++) {
						var tier = productResponse.tiers[i];
						var amountRange = "$" + tier.minAmount + " - $" + tier.maxAmount;
						addTableRow($table, headers, [ amountRange, tier.minRate + "%", tier.minAnnualRate + "%" ]);
					}
					if (productId == "MON") {
						setProductDisclosure($elem, "A $" + productResponse.tiers[0].minAmount + " minimum balance is required to open a money market account.");
					}
				}
				
				setGroupAsOf($rateElem, "Annual Percentage Yield");
				setGroupDescription($rateElem, rates.description.deposit);
				setGroupDisclosure($rateElem, rates.disclosure.deposit);
			} else if (groupId == "CON") {
				var headers = [ "Months", "Rate (APR)", "Payment per $1,000" ];
				var showOnlyApr = $.inArray(productId, [ "LIN", "PRE", "CAS", "SPE" ]) > -1;
				if (showOnlyApr) {
					headers = [ "Rate (APR)" ]; // just APR for loc and credit cards
				} else if (productId == "SIGNATURE") {
					headers[headers.length - 1] = "Payment per $100";
				}
				setTableHeaders($table, headers);
				var rows = [];
				for (var i = 0; i < productResponse.tiers.length; i++) {
					var tier = productResponse.tiers[i];
					var aprRange = tier.minAnnualRate + "% - " + tier.maxAnnualRate + "%";
					var paymentRange = "$" + tier.minAmount + " - $" + tier.maxAmount;
					if (showOnlyApr) {
						rows.push([ aprRange ]);
					} else {
						rows.push([ tier.monthsDuration, aprRange, paymentRange ]);
					}
				}
				$.each(rows, function (y, row) {
					addTableRow($table, headers, row);
				});
				
				if (productId == "VEHICLE") {
					setProductDisclosure($elem, rates.disclosure.vehicle);
				}
				
				setGroupAsOf($rateElem, "Annual Percentage Rate");
				setGroupDescription($rateElem, rates.description.consumer);
				setGroupDisclosure($rateElem, rates.definition.apr);
			} else if (groupId == "MOR") {
				var headers = [ "Term", "Rate", "APR", "Payment per $10,000" ];
				setTableHeaders($table, headers);
				for (var i = 0; i < productResponse.tiers.length; i++) {
					var tier = productResponse.tiers[i];
					var rateRange = tier.minRate + "% - " + tier.maxRate + "%";
					var aprRange = tier.minAnnualRate + "% - " + tier.maxAnnualRate + "%";
					var paymentRange = "$" + tier.minAmount + " - $" + tier.maxAmount;
					addTableRow($table, headers, [ (tier.monthsDuration / 12) + " years", rateRange, aprRange, paymentRange ]);
				}
				
				if (productId == "CON") {
					setProductDisclosure($elem, rates.disclosure.construction);
				} else if (productId == "PRI") {
					setProductDisclosure($elem, rates.disclosure.primary_mortgage);
				} else if (productId == "SEC") {
					setProductDisclosure($elem, rates.disclosure.secondary_mortgage);
				} else if (productId == "LAN") {
					setProductDisclosure($elem, rates.disclosure.land);
				}
				
				setGroupAsOf($rateElem, "Annual Percentage Rate");
				setGroupDescription($rateElem, rates.description.mortgage);
				setGroupDisclosure($rateElem, rates.definition.apr);
			} else if (groupId == "HOM") {
				var headers = [ "Term", "Rate (APR)", "Payment per $10,000" ];
				if (productId == "HELOC") {
					headers = [ "Rate (APR)" ];
				}
				setTableHeaders($table, headers);
				for (var i = 0; i < productResponse.tiers.length; i++) {
					var tier = productResponse.tiers[i];
					var row = [];
					if (productId == "HELOC") {
						row = [ tier.minAnnualRate + "%" ];
					} else {
						var aprRange = tier.minAnnualRate + "% - " + tier.maxAnnualRate + "%";
						var paymentRange = "$" + tier.minAmount + " - $" + tier.maxAmount;
						row = [ (tier.monthsDuration / 12) + " years", aprRange, paymentRange ];
					}
					addTableRow($table, headers, row);
				}
				
				if (productId == "HOM") {
					setProductDisclosure($elem, rates.disclosure.home_equity);
				}
				
				setGroupAsOf($rateElem, "Annual Percentage Rate");
				setGroupDescription($rateElem, rates.description.home_equity);
				setGroupDisclosure($rateElem, rates.definition.apr);
			}
		});
		
		$rateElem.find(".curr-date").text(getCurrentDate());
		
		$rateElem.find(".rate-products-holder").empty().append($productContainers);
		registerArrowToggle(); // reregister toggle expand/collapse for products
		
		openDesiredRateProduct();
		
		configureTabChangeEvent();
	}
	
	function getNumberOfSubTiers(tiers, distinguishingPropName) {
		var subTierIds = [];
		$.each(tiers, function (index, tier) {
			var tierId = tier[distinguishingPropName];
			if ($.inArray(tierId, subTierIds) < 0) {
				subTierIds.push(tierId);
			}
		});
		return subTierIds.length;
	}
	
	function setTableHeaders($table, headerTitles) {
		var $row = $("<tr></tr>");
		for (var i = 0; i < headerTitles.length; i++) {
			$row.append($("<th>" + headerTitles[i] + "</th>"));
		}
		$table.find("thead").append($row);
	}
	
	function addTableRow($table, headerTitles, values) {
		var $row = $("<tr></tr>");
		for (var i = 0; i < values.length; i++) {
			var title = headerTitles[i];
			var value = values[i];
			if (!value) {
				value = "";
			}
			$row.append($("<td data-th='" + title + "'>" + value + "</td>"));
		}
		$table.find("tbody").append($row);
	}
	
	// http://stackoverflow.com/a/3067896/1880761
	Date.prototype.mmddyyyy = function() {
		var mm = this.getMonth() + 1; // getMonth() is zero-based
		var dd = this.getDate();

		return [(mm > 9 ? '' : '0') + mm,
					(dd > 9 ? '' : '0') + dd,
					this.getFullYear()
				].join('-');
	};
	
	function getCurrentDate() {
		var date = new Date();
		return date.mmddyyyy();
	}
	
	function setProductDisclosure($productElem, text) {
		$productElem.find(".product-disclosure").text(text);
	}
	function setGroupAsOf($rateElem, text) {
		$rateElem.find(".group-as-of").text(text);
	}
	function setGroupDescription($rateElem, text) {
		$rateElem.find(".group-description").text(text);
	}
	function setGroupDisclosure($rateElem, text) {
		$rateElem.find(".group-disclosure").text(text);
	}
	
	function openDesiredRateGroup() {
		if (!rates.grouploaded) {
			var values = getRatePageLoadValues();
			if (values) {
				var groupId = values[0];
				var $tabs = $(".rates-homepage-cntr").find("[role=tab]");
				var $tab = $tabs.filter("#" + groupId);
				if ($tab.length) {
					$tab.trigger("click", $tab); // open group tab
					rates.grouploaded = true;
				}
			}
		}
	}
	
	function openDesiredRateProduct() {
		if (!rates.productloaded) {
			var values = getRatePageLoadValues();
			if (values && values.length > 1) {
				var productId = values[1];
				var $elem = $("#" + productId);
				if ($elem.length) {
					$elem.find("a.title").click();
					rates.productloaded = true;
				}
			}
		}
	}
	
	function getRatePageLoadValues() {
		/* values go in order of specificity: groupid-productid
			following are valid hashes:
							: empty/none, nothing will be opened on page load
				#CON		: will open consumer tab
				#CON-ATV	: will open consumer tab and then ATV group
		*/
		if (window.location.hash) {
			// replace # which is first character in hash value, then split out values
			return window.location.hash.substring(1).split("-");
		}
		return null;
	}
	
	function configureTabChangeEvent() {
		/*
		var $tabs = $(".rates-homepage-cntr").find("[role=tab]");
		$tabs.off("tabactivate").on("tabactivate", function (e, newTab) {
			var $tab = $(newTab);
			var currHash = window.location.hash;
			if (currHash) {
				// TODO, both on tab change event and on rate group open (.arrow-toggle-trigger)
			}
		});
		*/
	}
})();
