jQuery(document).ready(function($) {
	registerArrowToggle();
});
function registerArrowToggle() {
	var $trigger = $(".arrow-toggle-trigger");
	$trigger.off("click").on("click", function(event) {
		event.preventDefault();
		$(".arrow-toggle-content").removeClass("active");
		$(this).toggleClass("active").next(".arrow-toggle-content").addClass("active").slideToggle(200).end().parent("li").toggleClass("content-visible");
	});
}
