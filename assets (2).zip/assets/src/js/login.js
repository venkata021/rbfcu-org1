$(document).ready(function () {
	configureLogin();
	configureSearch();
	configureMenu();
});

var cookieKeyValue = "nbo=" + escape(new Date());
document.cookie = cookieKeyValue + ';expires=';

function configureLogin() {
	$(window).on("orientationchange resize", function() {
		$("body").removeClass("login-active");
	});
	
	$(".login-tog").click(function () {
		$("body").removeClass("search-active");
		$("body").toggleClass("login-active");
	});
	
	$(".login-full-tog").click(function () {
		$("#loginSheet").slideToggle();
	});
	
	$("#osType").val(navigator.platform);
	$("#osVersion").val(navigator.appVersion)
	$("#appDetail").val(navigator.userAgent);
	$("#cookiesEnabled").val(document.cookie.indexOf(cookieKeyValue) != -1);
	document.cookie = cookieKeyValue + ';expires=Thu, 01-Jun-2006 23:59:59 GMT';
}

function configureSearch() {
	$(window).on("orientationchange resize", function() {
		$("body").removeClass("search-active");
	});
	
	$(".search-tog").click(function () {
		$("body").removeClass("login-active");
		$("body").toggleClass("search-active");
		
		$("#searchSheet input[type='text']").focus();
	});
}

function configureMenu() {
	var $menu = $("#mob-menu").mmenu({
			// options
			"slidingSubmenus": false,
			"extensions": [
				"pagedim-black",
				"theme-dark"
			]
		}, {
			// configuration
			offCanvas: {
				pageSelector: "#base-area"
			},
			classNames: {
				fixedElements: {
					fixed: "hdr"
				}
			}
		});
	var $icon = $("#menu-icon");
	var API = $menu.data("mmenu");

	$icon.on("click", function () {
		API.open();
	});

	API.bind("opened", function () {
		setTimeout(function () {
			$icon.addClass("is-active");
		}, 100);
	});
	API.bind("closed", function () {
		setTimeout(function () {
			$icon.removeClass("is-active");
		}, 100);
	});
}
