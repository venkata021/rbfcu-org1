#!/bin/bash

if [ $# -gt 0 ]; then
	if [ "$1" == "c" ]; then
		node-sass assets/src/sass/fuse.scss assets/dist/css/fuse.min.css
		node-sass assets/src/sass/fuse.base.scss assets/dist/css/fuse.base.min.css
		node-sass assets/src/sass/featured-content.scss assets/dist/css/featured-content.min.css
	elif [ "$1" == "j" ]; then
		minify assets/src/js/ --template ../../dist/js/{{filename}}.min.{{ext}}
	fi
else
	bower install
	rm -rf assets/dist/css/*
	rm -rf assets/dist/js/*
	node-sass --output-style compressed assets/src/sass/fuse.scss assets/dist/css/fuse.min.css
	node-sass --output-style compressed assets/src/sass/fuse.base.scss assets/dist/css/fuse.base.min.css
	node-sass --output-style compressed assets/src/sass/featured-content.scss assets/dist/css/featured-content.min.css
	minify assets/src/js/ --template ../../dist/js/{{filename}}.min.{{ext}}
fi

