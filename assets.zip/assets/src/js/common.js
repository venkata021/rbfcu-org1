	// used for login cookie (determining javascript is enabled for browser)
	var cookieKeyValue = "nbo=" + escape(new Date());
	document.cookie = cookieKeyValue + ";expires=";

	// loader settings
	var opts = {
		lines: 9, // The number of lines to draw
		length: 9, // The length of each line
		width: 5, // The line thickness
		radius: 14, // The radius of the inner circle
		color: "#003474", // #rgb or #rrggbb or array of colors
		speed: 1.9, // Rounds per second
		trail: 40, // Afterglow percentage
		className: "spinner", // The CSS class to assign to the spinner
	};
	var target = document.getElementById("chart");

	$(document).ready(function() {
		configureLogin();
		configureSearch();
		configureMenu();
		configureSpinner();
		configureUsabilityFeatures();
		configureThirdPartyLinks();

		function configureLogin() {
			$(".login-tog").click(function () {
				$("body").toggleClass("login-active");
				$("html").addClass("html-active");
			});

			$(".login-full-tog").click(function () {
				$("#loginSheet").slideToggle();
			});

			$("#osType").val(navigator.platform);
			$("#osVersion").val(navigator.appVersion)
			$("#appDetail").val(navigator.userAgent);
			$("#cookiesEnabled").val(document.cookie.indexOf(cookieKeyValue) != -1);
			document.cookie = cookieKeyValue + ';expires=Thu, 01-Jun-2006 23:59:59 GMT';
			$("#username").focus();
		}

		function configureSearch() {
			$(".search-tog").click(function () {
				$("body").toggleClass("search-active");
				$("#searchSheet input[type='text']").focus();
			});

			$(document).on("keydown", function (e) {
				if (e.keyCode === 27) {
					// escape key
					$(".searchSheet").hide();
				}
			});
		}

		function configureMenu() {
			var $menu = $("#mob-menu").mmenu({
					// options
					"slidingSubmenus": false,
					"extensions": [
						"pagedim-black",
						"theme-dark"
					]
				}, {
					// configuration
					offCanvas: {
						pageSelector: "#base-area"
					},
					classNames: {
						fixedElements: {
							fixed: "hdr"
						}
					}
				});
			var $icon = $("#menu-icon");
			var API = $menu.data("mmenu");

			$icon.on("click", function () {
				API.open();
			});

			API.bind("opened", function () {
				setTimeout(function () {
					$icon.addClass("is-active");
				}, 100);
			});
			API.bind("closed", function () {
				setTimeout(function () {
					$icon.removeClass("is-active");
				}, 100);
			});
		}

		function configureUsabilityFeatures() {
			$("body").mousedown(function(e) {
				if (e.button == 1) {
					// middle click, disables viewing content overflow
					return false;
				}
			});
		}

		function configureThirdPartyLinks() {
			$("a[href*='myonlineinsurance.com'], a[href*='carvana.com'], a[href*='randolphbrooksfed.vlending.com'], a[href*='linkedin.com'], a[href*='rbfcu.mortgagewebcenter.com'], a[href*='petinsurance.com'], a[href*='rbfcu.cudlautosmart.com'], a[href*='randolphbrooksinsurance.consumerratequotes.com'],a[href*='rbrealty.com'],a[href*='salliemae.com'],a[href*='insuremyltc.com'],a[href*='deals.totalprotect.com'],a[href*='travelinsured.com'],a[href*='turbotax.intuit.com'],a[href*='rbfcu.wd5.myworkdayjobs.com']").addClass('no-external');
			$("a").filter(function () {
				var ignoreLink =
					this.hostname == location.hostname // disregard same domain
					|| this.href.match(/^(mailto|tel|javascript)\:/)
				return !ignoreLink;
			}).addClass("externalanchor").attr("target", "_blank");
		}
	});

	// callback function wrapped for loader in 'initSpinner' function
	function initSpinner() {
		// trigger loader
		var spinner = new Spinner(opts).spin(target);
		$(target).data("spinner", spinner);
		$("#chart").data("spinner").stop();
	}

	function configureSpinner() {
		$("#chart").click(function() {
			initSpinner();
		});
	}

			   $("form").submit(function (e) {
						$("input:visible").blur();
					$(this).find('input[type="submit"]').replaceWith("<div id='spinloader' style='position:relative;'/> <span>Loading</span></div>");
			 var target = document.getElementById("spinloader");
							var opts = {
								  lines: 7,
								  length: 0,
								  width: 5,
								  radius: 5,
								  corners: 1,
								  rotate: 0,
								  direction: 1,
								  color: "#000",
								  speed: 1,
								  trail: 60,
								  shadow: false,
								  hwaccel: false,
								  className: "spinner",
								  top: "6px",
								  left: "50%"
							};
							new Spinner(opts).spin(target);

						});   
	// callback function wrapped for loader in 'initSpinner' function
		function initSpinner() {
		// trigger loader
			var t1= $('#spinloader'); 
			var spinner = new Spinner(opts).spin(t1);
				$(target).data("spinner", spinner);
				$(submit).data("spinner").stop();
		}

		function configureSpinner() {
			$("#chart").click(function() {
			initSpinner();
		});
	}


		$.fn.scrollView = function () {
			return this.each(function () {
				$('html, body').animate({
				scrollTop: $(this).offset().top
				},0 );
	  });
	}

	$('.login-full-tog').click(function (event) {
		event.preventDefault();
	  $('#above-seg').scrollView();
	});