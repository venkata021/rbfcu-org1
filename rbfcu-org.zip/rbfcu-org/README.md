# rbfcu-org


Must have npm configured: https://wiki.rbfcu.org/x/Co29Bw

Also must have sass installed/configured in your path or node-sass via npm:

	npm install -g node-sass


To compile all items at once:

	./compile.sh

The previous script cleans the css and js output directories, and then compiles each item one by one:

	bower install
	node-sass --output-style compressed assets/src/sass/fuse.scss assets/dist/css/fuse.min.css
	node-sass --output-style compressed assets/src/sass/fuse.base.scss assets/dist/css/fuse.base.min.css
	node-sass --output-style compressed assets/src/sass/featured-content.scss assets/dist/css/featured-content.min.css
	minify assets/src/js/ --template ../../dist/js/{{filename}}.min.{{ext}}

Otherwise you can copy the plain (unminified) javascript files:

	cp assets/src/js/*.js assets/dist/js/


