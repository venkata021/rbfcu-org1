$(document).ready(function () {
	registerTabs();
});

function registerTabs() {
	$('.horizontal-tabs').each(function () {
		var $me = $(this);
		if ($me.data("active") !== true) {
			$me.easyResponsiveTabs({
				type: 'default', // types: default, vertical, accordion
				width: 'auto', // auto or any width like 600px
				fit: true   // 100% fit in a container
			});
			$me.data("active", true); // register tab group as activated
		}
	});
}