var gulp = require('gulp');
// var replace = require('gulp-url-replace');
// gulp.task('default', function() {
//     gulp.src('main.html')
//         .pipe(replace({
//             'assets/': 'monkey/'
//         }))
//         .pipe(gulp.dest("build/"))
// })

// var gulp = require('gulp');
// var htmlreplace = require('gulp-html-replace');

// gulp.task('default', function() {
//     gulp.src('main.html')
//         .pipe(htmlreplace({
//             fuse: {
//                 src: null,
//                 tpl: '@Html.StyleSheet(Url.WidgetContent(\'assets/dist/css/fuse.base.min.css\'), \'head\')'
//             },
//             rb_logo: {
//                 src: 'assets/images/_icons/rbfcu-logo.svg',
//                 tpl: '<img class=\'rbfcu-logo\' src=\'@Url.WidgetContent("%s")\' alt="RBFCU" />'
//             }
//         }))
//         .pipe(gulp.dest("build/"));
// });

var replace = require('gulp-replace');

gulp.task('default', function() {
    gulp.src(['main.html'])
        .pipe(replace('holder', 'foo'))
        .pipe(gulp.dest('build/'));
});
