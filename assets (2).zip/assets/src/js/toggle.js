jQuery(document).ready(function($) {
	registerArrowToggle();
});
function registerArrowToggle() {
	var $trigger = $('.arrow-toggle-trigger');
	var clickId = $trigger.data("click-id");
	if (!clickId) {
		clickId = "unknown";
	}
	var clickNamespace = "click." + clickId;
	$trigger.off(clickNamespace).on(clickNamespace, function(event) {
		event.preventDefault();
		$('.arrow-toggle-content').removeClass('active');
		$(this).toggleClass('active').next('.arrow-toggle-content').addClass('active').slideToggle(200).end().parent('li').toggleClass('content-visible');
	});
}
